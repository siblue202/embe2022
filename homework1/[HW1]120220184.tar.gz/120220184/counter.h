
#include "main.h"
#include <string.h>

void counter_process(struct shm_info_out * out_data, struct shm_info_in * in_data, enum COUNTER_MODE* clock_mode, int flag);
